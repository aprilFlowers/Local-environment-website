<?php
/**
 * Describes field labes
 */
class FieldLabel
{
    const REQUIRED = 1;
    const OPTIONAL = 2;
    const REPEATED = 3;
}

